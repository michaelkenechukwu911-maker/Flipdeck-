# Flipdeck — Mobile App Build Guide

This folder is a ready-to-go **Capacitor** project. Capacitor wraps your existing
web app (`www/index.html`) in a native shell so it installs and runs like a real
iOS/Android app — no rewrite needed.

## 0. Prerequisites (one-time setup on your computer)

- **Node.js** (v18+) — https://nodejs.org
- **For Android:** Android Studio — https://developer.android.com/studio
- **For iOS:** a Mac with Xcode installed (from the Mac App Store)

## 1. Install dependencies

Open a terminal in this folder and run:

```bash
npm install
npm install -g @capacitor/cli
```

## 2. Add the native platforms

```bash
npx cap add android
npx cap add ios      # only works on a Mac
```

This generates full native Xcode / Android Studio projects inside `ios/` and
`android/` folders — you won't need to touch native code directly.

## 3. Sync your web code into the native projects

Run this any time you change `www/index.html`:

```bash
npx cap sync
```

## 4. Open and run

```bash
npx cap open android    # launches Android Studio — press Run ▶
npx cap open ios        # launches Xcode — press Run ▶ (Mac only)
```

Each opens the native IDE with your app pre-loaded. Pick a simulator/emulator
or a plugged-in physical device and hit Run. Flipdeck will launch full-screen,
installed like any other app icon.

## 5. App icon & splash screen (recommended before publishing)

Drop a 1024×1024 PNG logo at `resources/icon.png` and a 2732×2732 splash at
`resources/splash.png`, then run:

```bash
npm install -g @capacitor/assets
npx capacitor-assets generate
npx cap sync
```

## 6. Publishing to the App Store / Play Store

- **Android:** In Android Studio, `Build > Generate Signed Bundle/APK`, then
  upload the `.aab` to the Google Play Console (~$25 one-time fee).
- **iOS:** In Xcode, set your Apple Developer team, `Product > Archive`, then
  upload via Xcode Organizer to App Store Connect (~$99/year Apple Developer
  Program membership required).

## 7. Also: deploy it as an installable PWA (web link + install button)

The `www/` folder is now a complete Progressive Web App — it has a
`manifest.json`, a service worker (`sw.js`) for offline caching, and app
icons. This gives you a shareable link that people can "Add to Home Screen"
on iOS/Android, and "Install" on desktop Chrome/Edge, with no App Store
review needed.

To deploy it:

1. Go to https://app.netlify.com/drop (or Vercel, or GitHub Pages)
2. Drag and drop the `www` folder onto the page
3. You'll get a live URL (e.g. `flipdeck.netlify.app`) — share that link
4. On a phone, visiting the link shows an "Add to Home Screen" / "Install"
   prompt; on desktop Chrome there's an install icon in the address bar

PWAs must be served over **HTTPS** (Netlify/Vercel/GitHub Pages all do this
automatically) — opening `index.html` directly from your file system will
skip the install prompt and offline support, though the app itself still
works fine.

You can offer both: the PWA link for instant access, and the native builds
from steps 1–6 for App Store / Play Store presence.

## Notes on the icons

The icons in `www/icons/` are simple placeholders (amber "F" mark on the
app's dark background). Swap them out with your own artwork any time —
just keep the same filenames and sizes (192×192, 512×512, and a 512×512
maskable version with extra padding for Android's adaptive icon shapes).


- Drawing uses the Pointer Events API, which already works with touch — no
  changes needed for finger/Apple Pencil/stylus input.
- The GIF export library loads from a CDN the *first* time you use Export
  GIF (needs a connection for that one moment). After that first use, the
  service worker has it cached, so exporting GIFs works offline too. Drawing,
  animating, and PNG export work fully offline from the very first launch.
- Canvas size is fixed at 640×480 internally and scales to fit the screen —
  works fine on phones but a tablet-sized canvas could look sharper on iPad;
  ask if you'd like that made responsive.
